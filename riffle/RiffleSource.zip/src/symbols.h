/////////////////////////////////////////////////////////////////////////////
// Name:        symbols.h
// Purpose:     Riffle symbols file
// Author:      Julian Smart
// Modified by:
// Copyright:   (c) Julian Smart
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _RIFFLE_SYMBOLS_H_
#define _RIFFLE_SYMBOLS_H_

//// Build settings

// Version
#define rfVERSION_NUMBER            1.0

#endif
